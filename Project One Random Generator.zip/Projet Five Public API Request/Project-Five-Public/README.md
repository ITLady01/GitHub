# Project Five Public
 Project Five Public Api Request
 The gallery background has been changed to beige 
 The header is also changed to beige
 The div gallery has been changed to blue
 The h1 header h1 is blue as well.
 The title has been changed to Startup Staff Directory
 The div card info the color is blue.

