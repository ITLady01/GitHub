# Project 4 Game show app
 
The changes that were made in the CSS file are the following:

1) In the root folder I changed the color-win:to the color rgb prupleRGB(180,120,207);


