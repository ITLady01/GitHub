Quotes= ['Be the change that you wish to see in the world.','Things change. And friends leave. Life doesn't stop for anybody.','Everyone thinks of changing the world, but no one thinks of changing himself.','Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has.];
console.log(quotes.length [0]);
console.log(quotes.length [4]);
